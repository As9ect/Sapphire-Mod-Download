BC = SMODS.current_mod

SMODS.load_file('utils.lua', 'bc_mods')()

BC.load_dir("objects/jokers")
