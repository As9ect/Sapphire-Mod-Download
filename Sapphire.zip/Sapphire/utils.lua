
function BC.load_file(file)
    local chunk, err = SMODS.load_file(file, "bc_mods")
    if chunk then
        local ok, func = pcall(chunk)
        if ok then
            return func
        else
            sendWarnMessage("Failed to process file: " .. func, "bc_mods")
        end
    else
        sendWarnMessage("Failed to find or compile file: " .. tostring(err), "bc_mods")
    end
    return nil
end

function BC.load_dir(directory)
    local files = NFS.getDirectoryItems(BC.path .. "/" .. directory)
    local regular_files = {}

    for _, filename in ipairs(files) do
        local file_path = directory .. "/" .. filename
        if file_path:match(".lua$") then
            if filename:match("^_") then
                BC.load_file(file_path)
            else
                table.insert(regular_files,file_path)
            end
        end
    end

    for _, file_path in ipairs(regular_files) do
        BC.load_file(file_path)
    end
end
