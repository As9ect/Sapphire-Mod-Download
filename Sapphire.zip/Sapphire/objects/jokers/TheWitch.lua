SMODS.Atlas{
  key = 'TW',
  path = 'IMG.png',
  px = 71,
  py = 95
}

SMODS.Joker{
  key = 'TW',
  atlas = 'TW',
  rarity = 3,
  cost = 8,
  unlocked = true,
  discovered = true,
  blueprint_compat = true,
  eternal_compat = true,
  perishable_compat = false,
  pos = {x = 0, y = 0},
  config = {
    extra = {
      Xmult = 2,
      odds = 6
    }
  },
  loc_vars = function(self,info_queue,center)
    return {
      vars = {
        center.ability.extra.Xmult,
        center.ability.extra.odds
      }
    }
  end,
  check_for_unlock = function(self, args)
    unlock_card(self)
  end,
  calculate = function(self,card,context)
    if context.before then
      rolled_value = pseudorandom("TheWitch")
      rolled_value2 = pseudorandom("TheWitch")
      odds_ratio = G.GAME.probabilities.normal / card.ability.extra.odds
      card.ability.extra.active = (rolled_value < odds_ratio)
      card.ability.extra.Dactive = (rolled_value > odds_ratio)
    if card.ability.extra.Dactive then
      return {
        message = 'Nope',
        colour = G.C.RED
      }
    elseif card.ability.extra.active then 
        for i = 1, #context.scoring_hand do
        if rolled_value2 < 0.25 then
              context.scoring_hand[i]:set_edition("e_polychrome")
          elseif rolled_value2 < 0.50 then
              context.scoring_hand[i]:set_edition("e_foil")
          elseif rolled_value2 < 0.75 then
              context.scoring_hand[i]:set_edition("e_holo")
          elseif rolled_value2 < 1 then
              context.scoring_hand[i]:set_edition("e_negative")
          end
          end
        end
      end
    end
}