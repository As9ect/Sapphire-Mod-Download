SMODS.Atlas{
  key = 'BD',
  path = 'BD.png',
  px = 71,
  py = 95
}

SMODS.Joker{
  key = 'BD',
  atlas = 'BD',
  rarity = 3,
  cost = 8,
  unlocked = true,
  discovered = true,
  blueprint_compat = true,
  eternal_compat = true,
  perishable_compat = false,
  pos = {x = 0, y = 0},
  config = {
    extra = {
    }
  },
  loc_vars = function(self,info_queue,center)
    return {
      vars = {
        center.ability.extra.tally
      }
    }
  end,
  check_for_unlock = function(self, args)
    unlock_card(self)
  end,
  calculate = function(self,card,context)
   if context.before then
        for i = 1, #context.scoring_hand do
          if context.before then
            return{
              message = 'Dyed',
              colour = G.C.RED,
              context.scoring_hand[i]:set_edition("e_foil")
            }
      end
    end
  end
end
}