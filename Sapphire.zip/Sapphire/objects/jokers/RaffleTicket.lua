SMODS.Atlas{
  key = 'RT',
  path = 'RT.png',
  px = 71,
  py = 95
}

SMODS.Joker{
  key = 'RT',
  atlas = 'RT',
  rarity = 3,
  cost = 8,
  unlocked = true,
  discovered = true,
  blueprint_compat = true,
  eternal_compat = true,
  perishable_compat = false,
  pos = {x = 0, y = 0},
  config = {
    extra = {
      Xmult = 2,
      odds = 4
    }
  },
  loc_vars = function(self,info_queue,center)
    return {
      vars = {
        center.ability.extra.Xmult,
        center.ability.extra.odds
      }
    }
  end,
  check_for_unlock = function(self, args)
    unlock_card(self)
  end,
  calculate = function(self,card,context)
    if context.joker_main then
      rolled_value = pseudorandom("RaffleTicket")
      odds_ratio = G.GAME.probabilities.normal / card.ability.extra.odds
      card.ability.extra.active = (rolled_value < odds_ratio)
      if card.ability.extra.active then
        return {
          xmult = card.ability.extra.Xmult
        }
      else
        return {}
      end
    end
 end
}
