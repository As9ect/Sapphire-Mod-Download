SMODS.Atlas{
  key = 'j_bluecrystal',
  path = 'j_bluecrystal.png',
  px = 71,
  py = 95
}

SMODS.Joker{
  key = 'bluecrystal',
  atlas = 'j_bluecrystal',
  rarity = 3,
  cost = 8,
  unlocked = true,
  discovered = true,
  blueprint_compat = true,
  eternal_compat = true,
  perishable_compat = true,
  pos = {x = 0, y = 0},
  config = {
    extra = {
      dollars_award = 1
    }
  },
  loc_vars = function(self, info_queue, center)
    return {
      vars = {
        center.ability.extra.dollars_award,
        localize(G.GAME.current_round.bluecrystal_card.suit, 'suits_singular'),
        colours = {G.C.SUITS[G.GAME.current_round.bluecrystal_card.suit]}
      }
    }
  end,
  check_for_unlock = function(self, args)
    unlock_card(self)
  end,
  calculate = function(self, card, context)
    if context.discard and not context.other_card.debuff and
			context.other_card:is_suit(G.GAME.current_round.bluecrystal_card.suit)
    then
      return {
        dollars = card.ability.extra.dollars_award
      }
    elseif context.end_of_round and context.cardarea == G.jokers then
      G.GAME.current_round.bluecrystal_card.suit = BC.random_valid_bluecrystal_suit()
    end
  end
}

BC.bluecrystal_card = { default_suit = 'Spades' }

function BC.random_valid_bluecrystal_suit()
  if not G.playing_cards then
    return BC.bluecrystal_card.default_suit
  end

	local valid_bc_cards = {}
	for _, v in ipairs(G.playing_cards) do
		if not SMODS.has_no_suit(v) then
			valid_bc_cards[#valid_bc_cards + 1] = v
		end
	end

	if valid_bc_cards[1] then
		local bc_card = pseudorandom_element(valid_bc_cards, pseudoseed('bc' .. G.GAME.round_resets.ante))
		return bc_card.base.suit
  else
		return BC.bluecrystal_card.default_suit
  end
end

local init_game_object_hook = Game.init_game_object
function Game:init_game_object()
	local ret = init_game_object_hook(self)
  ret.current_round.bluecrystal_card = { suit = BC.bluecrystal_card.default_suit }
	return ret
end

function SMODS.current_mod.reset_game_globals(run_start)
  local suit = BC.random_valid_bluecrystal_suit()
	G.GAME.current_round.bluecrystal_card = { suit = suit }
end
