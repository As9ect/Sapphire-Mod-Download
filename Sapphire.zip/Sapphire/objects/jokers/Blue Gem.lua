SMODS.Atlas{
  key = 'BG',
  path = 'BG.png',
  px = 71,
  py = 95
}

SMODS.Joker{
  key = 'BG',
  atlas = 'BG',
  rarity = 3,
  cost = 8,
  unlocked = true,
  discovered = true,
  blueprint_compat = true,
  eternal_compat = true,
  perishable_compat = false,
  pos = {x = 0, y = 0},
  config = {
    extra = {
      Chips = 0,
      Xmult = 1
    }
  },
  loc_vars = function(self,info_queue,center)
    return {
      vars = {
        center.ability.extra.Chips,
        center.ability.extra.Xmult
      }
    }
  end,
  check_for_unlock = function(self, args)
    unlock_card(self)
  end,
  calculate = function(self,card,context)
    if context.open_booster then
      card.ability.extra.Chips = card.ability.extra.Chips + 5
      card.ability.extra.Xmult = card.ability.extra.Xmult + 0.05
      return {
        message = 'Upgrade',
        colour = G.C.RED
      }
    elseif context.joker_main then
      return {
      chips = card.ability.extra.Chips,
      Xmult = card.ability.extra.Xmult
      }
    end
  end
}
