SMODS.Atlas{
  key = 'BC',
  path = 'BC.png',
  px = 71,
  py = 95
}

SMODS.Joker{
  key = 'BC',
  atlas = 'BC',
  rarity = 1,
  cost = 3,
  unlocked = true,
  discovered = true,
  blueprint_compat = true,
  eternal_compat = true,
  perishable_compat = false,
  pos = {x = 0, y = 0},
  config = {
    extra = {
      Chips = 0,
    }
  },
  loc_vars = function(self,info_queue,center)
    return {
      vars = {
        center.ability.extra.Chips
      }
    }
  end,
  check_for_unlock = function(self, args)
    unlock_card(self)
  end,
  calculate = function(self,card,context)
    if context.skipping_booster then
      card.ability.extra.Chips = card.ability.extra.Chips + 25
      return {
        message = 'Upgrade',
        colour = G.C.RED
      }
    elseif context.joker_main then
      return {
        chips = card.ability.extra.Chips
      }
    end
 end
}
