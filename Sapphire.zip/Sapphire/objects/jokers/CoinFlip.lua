SMODS.Atlas{
  key = 'CF',
  path = 'CF.png',
  px = 71,
  py = 95
}

SMODS.Joker{
  key = 'CF',
  atlas = 'CF',
  rarity = 3,
  cost = 8,
  unlocked = true,
  discovered = true,
  blueprint_compat = true,
  eternal_compat = true,
  perishable_compat = false,
  pos = {x = 0, y = 0},
  config = {
    extra = {
      odds = 6
    }
  },
  loc_vars = function(self,info_queue,center)
    return {
      vars = {
        center.ability.extra.odds,
        G.GAME.probabilities.normal
      }
    }
  end,
  check_for_unlock = function(self, args)
    unlock_card(self)
  end,
  calculate = function(self,card,context)
    if context.setting_blind then
      rolled_value2 = pseudorandom("CoinFlip")
      odds_ratio2 = G.GAME.probabilities.normal / card.ability.extra.odds
      card.ability.extra.activ2 = (rolled_value2 < odds_ratio2)
      if card.ability.extra.activ2 then
        G.GAME.current_round.discards_left = G.GAME.current_round.discards_left + 5
        return {
          message = '+5',
          colour = G.C.RED
        }
      end
          end
        end
}