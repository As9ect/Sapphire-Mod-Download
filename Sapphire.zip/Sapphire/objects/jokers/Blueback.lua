SMODS.Atlas{
  key = 'BB',
  path = 'BB.png',
  px = 71,
  py = 95
}

SMODS.Joker{
  key = 'BB',
  atlas = 'BB',
  rarity = 2,
  cost = 4,
  unlocked = true,
  discovered = true,
  blueprint_compat = true,
  eternal_compat = true,
  perishable_compat = false,
  pos = {x = 0, y = 0},
  config = {
    extra = {
      Chips = 0,
    }
  },
  loc_vars = function(self,info_queue,center)
    return {
      vars = {
        center.ability.extra.Chips
      }
    }
  end,
  check_for_unlock = function(self, args)
    unlock_card(self)
  end,
  calculate = function(self,card,context)
    if context.skip_blind then
      card.ability.extra.Chips = card.ability.extra.Chips + 50
      return {
        message = 'Upgrade',
        colour = G.C.RED
      }
      end
      if context.joker_main then
        return {
          chips = card.ability.extra.Chips
        }
      end
    end
}
