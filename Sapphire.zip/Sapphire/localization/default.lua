return {
  descriptions = {
    Joker = {
      j_bc_bluecrystal = {
        name = 'Blue Crystal',
        text = {
          'Earn {C:money}$#1#{} per',
          'discarded {V:1}#2#{} card,',
          'suit changes every round'
        }
      },
      j_bc_TW = {
          name = 'The Witch',
          text = {
            'This joker has a {C:green} 1 in 6',
            'to give all scored cards',
            'a random edition'
          }
        },
        j_bc_RT = {
          name = 'Raffle Ticket',
          text = {
            'This joker has a',
            '{C:green}1 in 4{} chance to give {X:mult,C:white}X#1#{} mult'
          }
        },
        j_bc_SS = {
          name = 'Sapphire Stone',
          text = {
            'This joker gains {C:blue}+9{} chips',
            'and {X:mult,C:white}X0.09{} mult',
            'after every hand played',
            '{C:inactive}(Currently {C:blue}+#2#{}{C:inactive} chips and {X:mult,C:white}X#1#{}{C:inactive}mult)'
          }
        },
        j_bc_BB = {
          name = 'Blue Back',
          text = {
            'This joker gains {C:blue}+50{} Chips',
            'for every blind skipped',
            '{C:inactive}(Currently {C:blue}+#1#{}{C:inactive} chips)'
          }
        },
        j_bc_BC = {
          name = 'Blue card',
          text = {
            'This joker gains {C:blue}+25{} Chips',
            'for every booster pack skipped',
            '{C:inactive}(Currently {C:blue}+#1#{}{C:inactive} chips{})'
          },
        },
        j_bc_BD = {
          name = 'Blue Dye',
          text = {
            'This joker gives the',
            '{C:attention}foil edition{} to the first',
            'scored card of hand'
          }
        },
        j_bc_CF = {
          name = 'Coin flip',
          text = {
            'This joker has a {C:green}#2# in #1#{}',
            'chance to give {C:red}+5 discards{}'
          }
        },
        j_bc_BG = {
          name = 'Blue Gem',
          text = {
            'This joker gains {C:blue}+5{} chips',
            'and {X:mult,C:white}X0.05{} mult',
            'for every consumeable used',
            '{C:inactive}(Currently {C:blue}+#1#{}{C:inactive} chips and {X:mult,C:white}X#2#{}{C:inactive} mult)'
          }
        }
      }
  }
}
